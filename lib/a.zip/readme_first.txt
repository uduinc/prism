In order to view the  the downloadable database (pdf) file(s) you will need Adobe Acrobat Reader installed.  To download this software from the Adobe  web site (at no cost) please copy and paste the link below into your web browser's address bar. 

This will take you to the Adobe web site where you can download a version of Acrobat Reader..

http://www.adobe.com/products/acrobat/readstep2.html 

****************************************************************************************************

Download the latest version of Microsoft Access Viewer (at no cost) to view the downloadable database (mdb) file(s).  Please copy and paste the link below into your web browser's address bar.

This will take you to the Microsoft Office Online web site where you can download a version of Microsoft Access Viewer.

http://office.microsoft.com/en-us/downloads/HA010449811033.aspx. 

****************************************************************************************************

Download the latest version of Microsoft Excel Viewer (at no cost) to view the downloadable database (csv) file(s).  Please copy and paste the link below into your web browser's address bar.

This will take you to the Microsoft Office Online web site where you can download a version of Microsoft Excel Viewer.
 
http://office.microsoft.com/en-us/downloads/HA010449811033.aspx.


NOTE:  Some of the information within the .csv file(s) may contain web characters (examples:  &#, #, <br>, <b>, <i>, <ul>, <li>, etc...).  When using screen reading software, please be aware of these characters when going through the data.